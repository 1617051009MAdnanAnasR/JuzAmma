package com.example.asus.juzamma;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;

public class ayat extends AppCompatActivity {
    WebView mWebView;
    TextView mText;
    ImageView imageView_kiblat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ayat);
        mText = (TextView)findViewById(R.id.text);
        setInitalisasi();
        cekIntent();
    }

    private void cekIntent() {
        Intent cek = getIntent();
        String nama_surah = cek.getStringExtra("nama_surah");

        if (nama_surah.equals("1")){
                try {
                    InputStream is = getAssets().open("1.txt");
                    int size = is.available();
                    byte[] buffer = new byte[size];
                    is.read(buffer);
                    is.close();
                    mText.setText(new String(buffer));
                }
                catch (IOException ex) {
                    return;
                }
        } else if (nama_surah.equals("2")){
            try {
                InputStream is = getAssets().open("2.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        } else if (nama_surah.equals("3")){
            try {
                InputStream is = getAssets().open("3.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        } else if (nama_surah.equals("4")) {
            try {
                InputStream is = getAssets().open("4.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        } else if (nama_surah.equals("5")) {
            try {
                InputStream is = getAssets().open("5.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }


        } else if (nama_surah.equals("6")) {
            try {
                InputStream is = getAssets().open("6.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }


        } else if (nama_surah.equals("7")) {
            try {
                InputStream is = getAssets().open("7.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }


        } else if (nama_surah.equals("8")) {
            try {
                InputStream is = getAssets().open("8.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }


        } else if (nama_surah.equals("9")) {
            try {
                InputStream is = getAssets().open("9.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        } else if (nama_surah.equals("10")) {
            try {
                InputStream is = getAssets().open("10.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }


        }else if (nama_surah.equals("11")) {
            try {
                InputStream is = getAssets().open("11.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("12")) {
            try {
                InputStream is = getAssets().open("12.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }


        }else if (nama_surah.equals("13")) {
            try {
                InputStream is = getAssets().open("13.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }


        }else if (nama_surah.equals("14")) {
            try {
                InputStream is = getAssets().open("14.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }


        }else if (nama_surah.equals("15")) {
            try {
                InputStream is = getAssets().open("15.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }


        }else if (nama_surah.equals("16")) {
            try {
                InputStream is = getAssets().open("16.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("17")) {
            try {
                InputStream is = getAssets().open("17.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("18")) {
            try {
                InputStream is = getAssets().open("18.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("19")) {
            try {
                InputStream is = getAssets().open("19.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("20")) {
            try {
                InputStream is = getAssets().open("20.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("21")) {
            try {
                InputStream is = getAssets().open("21.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("22")) {
            try {
                InputStream is = getAssets().open("22.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("23")) {
            try {
                InputStream is = getAssets().open("23.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("24")) {
            try {
                InputStream is = getAssets().open("24.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("25")) {
            try {
                InputStream is = getAssets().open("25.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("26")) {
            try {
                InputStream is = getAssets().open("26.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("27")) {
            try {
                InputStream is = getAssets().open("27.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("28")) {
            try {
                InputStream is = getAssets().open("28.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("29")) {
            try {
                InputStream is = getAssets().open("29.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("30")) {
            try {
                InputStream is = getAssets().open("30.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("31")) {
            try {
                InputStream is = getAssets().open("31.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("32")) {
            try {
                InputStream is = getAssets().open("32.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("33")) {
            try {
                InputStream is = getAssets().open("33.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("34")) {
            try {
                InputStream is = getAssets().open("34.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("35")) {
            try {
                InputStream is = getAssets().open("35.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("36")) {
            try {
                InputStream is = getAssets().open("36.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("37")) {
            try {
                InputStream is = getAssets().open("37.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }else if (nama_surah.equals("38")) {
            try {
                InputStream is = getAssets().open("38.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                mText.setText(new String(buffer));
            }
            catch (IOException ex) {
                return;
            }

        }
        else {
            imageView_kiblat.setImageResource(R.drawable.audio2);

        }

    }

    private void setInitalisasi() {
        imageView_kiblat = (ImageView)findViewById(R.id.imageView_kiblat);

    }
}

