package com.example.asus.juzamma;
import android.app.ProgressDialog;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;
public class audiop extends AppCompatActivity {
    private Button btn;
    private boolean playPause;
    private MediaPlayer mediaPlayer;
    private ProgressDialog progressDialog;
    private boolean initialStage = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audiop);
        btn = (Button) findViewById(R.id.audioStreamBtn);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/fatihah.mp3?alt=media&token=7eaf91c9-576d-495f-a858-5f3e4f6981c6"
                        );
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn.setText("Al-Fatihah");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn2 = (Button) findViewById(R.id.button2);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn2.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/annas.mp3?alt=media&token=fddd2dac-c160-407f-a6a4-3fea8fb9ee45"
                        );
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn2.setText("An-Nas");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn3 = (Button) findViewById(R.id.button3);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn3.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn3.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/alfalaq.mp3?alt=media&token=c15feb2d-afd1-4e49-8fea-b52d831b5217");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn3.setText("Al-Falaq");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn4 = (Button) findViewById(R.id.button4);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn4.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn4.setText("Berhenti");
                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/alikhlas.mp3?alt=media&token=40d73424-5ce8-4e74-b259-471980cdde60");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn4.setText("Al-Ikhlas");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn5 = (Button) findViewById(R.id.button5);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn5.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn5.setText("Berhenti.");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/allahab.mp3?alt=media&token=c7cc339c-da57-4a05-ada7-3cdfdbd99a41");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn5.setText("Al-Lahab");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn6 = (Button) findViewById(R.id.button6);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn6.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn6.setText("Berhenti.");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/annasr.mp3?alt=media&token=af0afac2-16c7-417f-95c5-da2eab60294d");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn6.setText("An-Nasr");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn7 = (Button) findViewById(R.id.button7);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn7.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn7.setText("Berhenti.");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/alkafirun.mp3?alt=media&token=0ad864e7-fb2b-4e9c-97bd-201352777341");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn7.setText("Al-Kafirun");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn8 = (Button) findViewById(R.id.button8);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn8.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn8.setText("Berhenti.");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/alkautsar.mp3?alt=media&token=085fee31-1ee8-4d97-a61d-040e4be7e5ed");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn8.setText("Al-Kautsar");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn9 = (Button) findViewById(R.id.button9);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn9.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn9.setText("Berhenti.");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/almaun.mp3?alt=media&token=dc64bbd4-5c3c-4da9-94f7-db0be68836ed");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn9.setText("Al-Maun");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn10 = (Button) findViewById(R.id.button10);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn10.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn10.setText("Berhenti.");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/quraysh.mp3?alt=media&token=e58403c2-648a-4ba5-b640-790378eb02c5");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn10.setText("Quraisy");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn11 = (Button) findViewById(R.id.button11);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn11.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn11.setText("Berhenti.");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/alfil.mp3?alt=media&token=5fdfb23c-4fc4-473a-9dc5-149c154fe7de");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn11.setText("Al-Fil");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn12 = (Button) findViewById(R.id.button12);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn12.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn12.setText("Berhenti.");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/alhumazah.mp3?alt=media&token=aa54838d-5094-4ac1-95f1-5213e4569e06");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn12.setText("Al-Humazah");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn13 = (Button) findViewById(R.id.button13);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn13.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn13.setText("Berhenti.");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn13.setText("Al-Asr");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn14 = (Button) findViewById(R.id.button14);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn14.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn14.setText("Berhenti.");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/attakasur.mp3?alt=media&token=0a515914-24d8-40f8-9661-e8e96913b261");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn14.setText("Al-Takatsur");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn15 = (Button) findViewById(R.id.button15);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn15.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn15.setText("Berhenti.");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/alqoriah.mp3?alt=media&token=93a4bf16-a687-4c67-a213-4d6a11590a4f");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn15.setText("Al-Qoriah");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn16 = (Button) findViewById(R.id.button16);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn16.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn16.setText("Berhenti.");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/aladiyat.mp3?alt=media&token=b5302613-e32d-47fe-966b-aad271145dd2");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn16.setText("Al-Adiyat");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn17 = (Button) findViewById(R.id.button17);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn17.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn17.setText("Berhenti.");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/azzalzalah.mp3?alt=media&token=dd99ad29-5c81-4f09-81f6-b82872278146");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn17.setText("Az-Zalzalah");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn18 = (Button) findViewById(R.id.button18);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn18.setText("Berhenti.");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/albayinah.mp3?alt=media&token=dccb6628-6100-47d0-8520-88747bdc345a");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn18.setText("Al-Bayyinah");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn19 = (Button) findViewById(R.id.button19);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn19.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn19.setText("Berhenti.");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/alqodr.mp3?alt=media&token=9f4d43e3-c005-4f41-b91d-ac40f93e6b18");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn19.setText("Al-Qadr");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn20 = (Button) findViewById(R.id.button20);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn20.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn20.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/alalaq.mp3?alt=media&token=db647951-b2f7-4c7f-a81a-2b713a9e5396");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn20.setText("Al-Alaq");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn21 = (Button) findViewById(R.id.button21);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn21.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn21.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/attin.mp3?alt=media&token=ee8224ec-a6f1-4702-af2a-3cd31034afc2");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn21.setText("At-Tin");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn22 = (Button) findViewById(R.id.button22);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn22.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn22.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/alinsiroh.mp3?alt=media&token=034d7445-fa5b-44bc-870d-da62c640a5da");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn22.setText("Al-Insiroh");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn23 = (Button) findViewById(R.id.button23);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn23.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn23.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/adduha.mp3?alt=media&token=f644c38b-4015-4f69-8fd0-08198f4690f1");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn23.setText("Ad-Duhaa");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn24 = (Button) findViewById(R.id.button24);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn24.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn24.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/allail.mp3?alt=media&token=6d110a23-63cc-449c-8b6a-07e46c0a8f25");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn24.setText("Al-Layl");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn25 = (Button) findViewById(R.id.button25);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn25.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn25.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/assyams.mp3?alt=media&token=ab01c31f-8599-4fb2-a9ef-80fad4ff0d86");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn25.setText("Ash-Syams");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn26 = (Button) findViewById(R.id.button26);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn26.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn26.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/albalad.mp3?alt=media&token=882a5fd9-a329-4446-aee7-f0d8e5932e9a");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn26.setText("Al-Balad");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn27 = (Button) findViewById(R.id.button27);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn27.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn27.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/alfajr.mp3?alt=media&token=4da5c17b-9b16-49c9-a568-a68868a4b384");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn27.setText("Al-Fajr");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn28 = (Button) findViewById(R.id.button28);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn28.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn28.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/algosiah.mp3?alt=media&token=1dac86f0-c41c-4053-a3bc-0d7db611dfb5");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn28.setText("Al-Ghasiah");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn29 = (Button) findViewById(R.id.button29);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn29.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn29.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/alala.mp3?alt=media&token=9d0547a5-dab6-431e-89d6-fd01250b2759");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn29.setText("Al-A'la");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn30 = (Button) findViewById(R.id.button30);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn30.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn30.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/atoriq.mp3?alt=media&token=d115bbb5-29a7-41d6-9c9e-4a9a49aafef7");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn30.setText("Al-Thariq");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn31 = (Button) findViewById(R.id.button31);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn31.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn31.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/alburuj.mp3?alt=media&token=4e402de9-ded9-4562-b4fa-73a0af2809bb");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn31.setText("Al-Buruj");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn32 = (Button) findViewById(R.id.button32);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn32.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn32.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/alinsiqoqo.mp3?alt=media&token=57e98d66-52e8-4970-9937-1eb82e0e8661");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn32.setText("Al-Insiqaq");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn33 = (Button) findViewById(R.id.button33);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn33.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn33.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/almutofifin.mp3?alt=media&token=ab28ad6a-ee08-4fc1-97db-ac48d3168221");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn33.setText("Al-Mutaffifin");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn34 = (Button) findViewById(R.id.button34);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn34.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn34.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/alinfitor.mp3?alt=media&token=7a43a078-e4d9-42e5-8023-3f0647819850");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn34.setText("Al-Infitar");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn35 = (Button) findViewById(R.id.button35);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn35.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn35.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/atakwir.mp3?alt=media&token=892dfeab-ca62-4b07-8c4a-8fe90b175292");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn35.setText("At-Takwir");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn36 = (Button) findViewById(R.id.button36);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn36.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn36.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/Abasa.mp3?alt=media&token=f3423bd4-1094-471c-ab9a-f2e74f8f01f6");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn36.setText("Abasa");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn37 = (Button) findViewById(R.id.button37);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn37.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn37.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/anaziat.mp3?alt=media&token=1829c5a9-28d7-4c39-a494-1072e8611fdc");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn37.setText("An-Naziat");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
        final Button btn38 = (Button) findViewById(R.id.button38);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        progressDialog = new ProgressDialog(this);
        btn38.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                if (!playPause) {
                    btn38.setText("Berhenti");

                    if (initialStage) {
                        new com.example.asus.juzamma.audiop.Player().execute("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/anaba.mp3?alt=media&token=34d9fd83-7d43-434a-989d-fc50e4c2c755");
                    } else {
                        if (!mediaPlayer.isPlaying())
                            mediaPlayer.start();
                    }

                    playPause = true;

                } else {
                    btn38.setText("An-Naba");

                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }

                    playPause = false;
                }
            }
        });
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    class Player extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... strings) {
            Boolean prepared = false;

            try {
                mediaPlayer.setDataSource(strings[0]);
                mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mediaPlayer) {
                        initialStage = true;
                        playPause = false;
                        mediaPlayer.stop();
                        mediaPlayer.reset();
                    }
                });

                mediaPlayer.prepare();
                prepared = true;

            } catch (Exception e) {
                Log.e("MyAudioStreamingApp", e.getMessage());
                prepared = false;
            }

            return prepared;
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            super.onPostExecute(aBoolean);

            if (progressDialog.isShowing()) {
                progressDialog.cancel();
            }

            mediaPlayer.start();
            initialStage = false;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog.setMessage("Tunggu Sebentar...");
            progressDialog.show();
        }

    }
}