package com.example.asus.juzamma;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    ImageView imageView_quran, imageView_kiblat, imageView_tentang,imageView_audio;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        waktuNgaji();


        setInisialisasi();
        onClickMantab();
    }

    private void onClickMantab() {

        imageView_kiblat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent d = new Intent(MainActivity.this,Waktungaji.class);
                startActivity(d);
            }
        });

        imageView_tentang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent c = new Intent(MainActivity.this,tentang.class);
                startActivity(c);
            }
        });

        imageView_quran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(MainActivity.this, mengaji.class);
                startActivity(a);
            }
        });

        imageView_audio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent al = new Intent(MainActivity.this,audiop.class);
                startActivity(al);
            }
        });
    }

    private void setInisialisasi() {
        imageView_audio = (ImageView)findViewById(R.id.imageView_audio);
        imageView_quran = (ImageView)findViewById(R.id.imageView_quran);
        imageView_tentang = (ImageView)findViewById(R.id.imageView_tentang);
        imageView_kiblat = (ImageView)findViewById(R.id.imageView_kiblat);
    }

    private void waktuNgaji(){
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY,3);
        calendar.set(Calendar.MINUTE,30);
        calendar.set(Calendar.SECOND,0);

        Intent intent = new Intent(MainActivity.this, AlarmReceiver.class);
        PendingIntent pendingIntent= PendingIntent.getBroadcast(MainActivity.this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager am=(AlarmManager)this.getSystemService(this.ALARM_SERVICE);
        am.setRepeating(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);
    }
}
