package com.example.asus.juzamma;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ToggleButton;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import static com.example.asus.juzamma.R.string.app_name;

public class mengaji extends AppCompatActivity {
    MediaPlayer mp,mediaPlayer;
    Button butt,button,button2,button3,button4,button5,button6,button7,button8,button9,button10
            ,button11,button12,button13,button14,button15,button16,button17,button18,button19,button20
            ,button21,button22,button23,button24,button25,button26,button27,button28,button29,button30
            ,button31,button32,button33,button34,button35,button36,button37,button38,btn;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mengaji);
        setInisialisasi();
        onClickMantab();

    }
    public void play_song(View v) {
        MediaPlayer mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource("https://firebasestorage.googleapis.com/v0/b/audio-ngaji.appspot.com/o/G.O.D%20-%20PHP%20ft.%20ULIMHO.mp3?alt=media&token=f1847f91-a0aa-408a-8d4e-64a95039b1c5");
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mp.start();
                }
            });
            mediaPlayer.start();
        } catch (IOException e) {
            e.getMessage();
        }
    }

    private void onClickMantab() {

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent d = new Intent(mengaji.this,ayat.class);
                d.putExtra("nama_surah","1");
                startActivity(d);
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent c = new Intent(mengaji.this,ayat.class);
                c.putExtra("nama_surah","2");
                startActivity(c);
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent b = new Intent(mengaji.this,ayat.class);
                b.putExtra("nama_surah","3");
                startActivity(b);
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(mengaji.this,ayat.class);
                a.putExtra("nama_surah","4");
                startActivity(a);
            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent e = new Intent(mengaji.this,ayat.class);
                e.putExtra("nama_surah","5");
                startActivity(e);
            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent f = new Intent(mengaji.this,ayat.class);
                f.putExtra("nama_surah","6");
                startActivity(f);
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent g = new Intent(mengaji.this,ayat.class);
                g.putExtra("nama_surah","7");
                startActivity(g);
            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent h = new Intent(mengaji.this,ayat.class);
                h.putExtra("nama_surah","8");
                startActivity(h);
            }
        });
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mengaji.this,ayat.class);
                i.putExtra("nama_surah","9");
                startActivity(i);
            }
        });
        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent j = new Intent(mengaji.this,ayat.class);
                j.putExtra("nama_surah","10");
                startActivity(j);
            }
        });
        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent k = new Intent(mengaji.this,ayat.class);
                k.putExtra("nama_surah","11");
                startActivity(k);
            }
        });
        button12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent l = new Intent(mengaji.this,ayat.class);
                l.putExtra("nama_surah","12");
                startActivity(l);
            }
        });
        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent m = new Intent(mengaji.this,ayat.class);
                m.putExtra("nama_surah","13");
                startActivity(m);
            }
        });
        button14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent n = new Intent(mengaji.this,ayat.class);
                n.putExtra("nama_surah","14");
                startActivity(n);
            }
        });
        button15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent o = new Intent(mengaji.this,ayat.class);
                o.putExtra("nama_surah","15");
                startActivity(o);
            }
        });
        button16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(mengaji.this,ayat.class);
                p.putExtra("nama_surah","16");
                startActivity(p);
            }
        });
        button17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent q = new Intent(mengaji.this,ayat.class);
                q.putExtra("nama_surah","17");
                startActivity(q);
            }
        });
        button18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent r = new Intent(mengaji.this,ayat.class);
                r.putExtra("nama_surah","18");
                startActivity(r);
            }
        });
        button19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent s = new Intent(mengaji.this,ayat.class);
                s.putExtra("nama_surah","19");
                startActivity(s);
            }
        });
        button20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent t = new Intent(mengaji.this,ayat.class);
                t.putExtra("nama_surah","20");
                startActivity(t);
            }
        });
        button21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent u = new Intent(mengaji.this,ayat.class);
                u.putExtra("nama_surah","21");
                startActivity(u);
            }
        });
        button22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent v = new Intent(mengaji.this,ayat.class);
                v.putExtra("nama_surah","22");
                startActivity(v);
            }
        });
        button23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent w = new Intent(mengaji.this,ayat.class);
                w.putExtra("nama_surah","23");
                startActivity(w);
            }
        });
        button24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent x = new Intent(mengaji.this,ayat.class);
                x.putExtra("nama_surah","24");
                startActivity(x);
            }
        });
        button25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent y = new Intent(mengaji.this,ayat.class);
                y.putExtra("nama_surah","25");
                startActivity(y);
            }
        });
        button26.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent z = new Intent(mengaji.this,ayat.class);
                z.putExtra("nama_surah","26");
                startActivity(z);
            }
        });
        button27.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent za = new Intent(mengaji.this,ayat.class);
                za.putExtra("nama_surah","27");
                startActivity(za);
            }
        });
        button28.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent zb = new Intent(mengaji.this,ayat.class);
                zb.putExtra("nama_surah","28");
                startActivity(zb);
            }
        });
        button29.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent zc = new Intent(mengaji.this,ayat.class);
                zc.putExtra("nama_surah","29");
                startActivity(zc);
            }
        });
        button30.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent zd = new Intent(mengaji.this,ayat.class);
                zd.putExtra("nama_surah","30");
                startActivity(zd);
            }
        });
        button31.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ze = new Intent(mengaji.this,ayat.class);
                ze.putExtra("nama_surah","31");
                startActivity(ze);
            }
        });
        button32.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent zf = new Intent(mengaji.this,ayat.class);
                zf.putExtra("nama_surah","32");
                startActivity(zf);
            }
        });
        button33.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent zg = new Intent(mengaji.this,ayat.class);
                zg.putExtra("nama_surah","33");
                startActivity(zg);
            }
        });
        button34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent zh = new Intent(mengaji.this,ayat.class);
                zh.putExtra("nama_surah","34");
                startActivity(zh);
            }
        });
        button35.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent zi = new Intent(mengaji.this,ayat.class);
                zi.putExtra("nama_surah","35");
                startActivity(zi);
            }
        });
        button36.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent zj = new Intent(mengaji.this,ayat.class);
                zj.putExtra("nama_surah","36");
                startActivity(zj);
            }
        });
        button37.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent zk = new Intent(mengaji.this,ayat.class);
                zk.putExtra("nama_surah","37");
                startActivity(zk);
            }
        });
        button38.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent zl = new Intent(mengaji.this,ayat.class);
                zl.putExtra("nama_surah","38");
                startActivity(zl);
            }
        });
}

    private void setInisialisasi() {
        button = findViewById(R.id.button);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);
        button10 = findViewById(R.id.button10);
        button11 = findViewById(R.id.button11);
        button12 = findViewById(R.id.button12);
        button13 = findViewById(R.id.button13);
        button14 = findViewById(R.id.button14);
        button15 = findViewById(R.id.button15);
        button16 = findViewById(R.id.button16);
        button17 = findViewById(R.id.button17);
        button18 = findViewById(R.id.button18);
        button19 = findViewById(R.id.button19);
        button20 = findViewById(R.id.button20);
        button21 = findViewById(R.id.button21);
        button22 = findViewById(R.id.button22);
        button23 = findViewById(R.id.button23);
        button24 = findViewById(R.id.button24);
        button25 = findViewById(R.id.button25);
        button26 = findViewById(R.id.button26);
        button27 = findViewById(R.id.button27);
        button28 = findViewById(R.id.button28);
        button29 = findViewById(R.id.button29);
        button30 = findViewById(R.id.button30);
        button31 = findViewById(R.id.button31);
        button32 = findViewById(R.id.button32);
        button33 = findViewById(R.id.button33);
        button34 = findViewById(R.id.button34);
        button35 = findViewById(R.id.button35);
        button36 = findViewById(R.id.button36);
        button37 = findViewById(R.id.button37);
        button38 = findViewById(R.id.button38);



    }

}